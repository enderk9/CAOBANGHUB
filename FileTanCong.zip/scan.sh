#!/bin/bash

# File tạm
ALL_PROXIES="all_proxies.txt"
LIVE_PROXIES="live_proxies.txt"

# Xóa file cũ nếu có
> "$ALL_PROXIES"
> "$LIVE_PROXIES"

# Nguồn proxy (HTTP/HTTPS)
sources=(
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt"
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt"
    "https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt"
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt"
    "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt"
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt"
    "https://raw.githubusercontent.com/UserR3X/proxy-list/main/http.txt"
    "https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt"
    "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt"
    "https://www.proxy-list.download/api/v1/get?type=http"
    "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all"
    "https://www.proxyscan.io/download?type=http"
    "https://proxyspace.pro/http.txt"
    "https://geonode.com/free-proxy-list/output.txt"
    "https://www.proxynova.com/proxy-server-list/country-all/"
    "https://free-proxy-list.net/"
    "https://www.sslproxies.org/"
    "https://free-proxy.cz/en/proxylist/main/"
    "https://www.my-proxy.com/free-proxy-list.html"
    "https://openproxy.space/list/http"
)

echo "[+] Đang tải proxy từ các nguồn..."

for url in "${sources[@]}"; do
    echo "[*] $url"
    curl -s "$url" >> "$ALL_PROXIES"
done

# Làm sạch và lọc proxy theo định dạng IP:PORT
grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}:[0-9]{2,5}' "$ALL_PROXIES" | sort -u > "$ALL_PROXIES.clean"
mv "$ALL_PROXIES.clean" "$ALL_PROXIES"

echo "[+] Đã thu thập $(wc -l < "$ALL_PROXIES") proxy hợp lệ."

# Hàm kiểm tra proxy
check_proxy() {
    proxy=$1
    if timeout 5 curl -s --proxy "http://$proxy" http://httpbin.org/ip >/dev/null; then
        echo "$proxy" >> "$LIVE_PROXIES"
        echo "[LIVE] $proxy"
    else
        echo "[DEAD] $proxy"
    fi
}

export -f check_proxy
export LIVE_PROXIES

echo "[+] Bắt đầu lọc proxy (song song)..."
cat "$ALL_PROXIES" | xargs -P 100 -I {} bash -c 'check_proxy "{}"'

echo "[+] Hoàn tất! Proxy live: $(wc -l < "$LIVE_PROXIES")"
echo "[+] Đã lưu tại: live_proxies.txt"