#!/bin/bash

INPUT_FILE="live_proxies.txt"
OUTPUT_FILE="rechecked_live.txt"

if [ ! -f "$INPUT_FILE" ]; then
    echo "[!] Không tìm thấy file $INPUT_FILE"
    exit 1
fi

> "$OUTPUT_FILE"

echo "[+] Đang kiểm tra lại proxy từ $INPUT_FILE..."

# Hàm kiểm tra proxy
check_proxy() {
    proxy=$1
    if timeout 5 curl -s --proxy "http://$proxy" http://httpbin.org/ip >/dev/null; then
        echo "$proxy" >> "$OUTPUT_FILE"
        echo "[LIVE] $proxy"
    else
        echo "[DEAD] $proxy"
    fi
}

export -f check_proxy
export OUTPUT_FILE

cat "$INPUT_FILE" | xargs -P 100 -I {} bash -c 'check_proxy "{}"'

echo "[+] Hoàn tất! Proxy còn sống: $(wc -l < "$OUTPUT_FILE")"
echo "[+] Đã lưu tại: $OUTPUT_FILE"